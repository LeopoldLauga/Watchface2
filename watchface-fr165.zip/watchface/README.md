# ThursdayFace — Garmin FR165 Watchface

## Project Structure
```
watchface/
├── manifest.xml
├── source/
│   └── WatchFace.mc        ← main code
└── resources/
    ├── strings/
    │   └── strings.xml
    └── drawables/
        ├── drawables.xml
        └── launcher_icon.png  ← add a 70x70px PNG icon
```

## What's displayed
- Large teal time (HH:MM) in centre
- Seconds (small, right-aligned)
- Date badge (white pill, top centre)
- Three bottom widgets:
  - Left: Weather temperature + cloud icon
  - Centre: Activity rings (steps outer, HR inner) + HR value
  - Right: Step count

## Build & deploy options

### Option A — VS Code + Connect IQ SDK (recommended)
1. Install VS Code + Monkey C extension
2. Open this folder in VS Code
3. Press F5 to run in simulator
4. Connect FR165 via USB → Run on Device

### Option B — Cloud Build (no SDK needed)
1. Push this project to a GitHub repo
2. Go to developer.garmin.com → Cloud Build
3. Point it at your repo
4. Download the compiled .prg file
5. Copy .prg to GARMIN/APPS/ on your watch via USB

## Notes
- Launcher icon: add a 70×70px PNG named `launcher_icon.png` in resources/drawables/
- App ID in manifest.xml is a placeholder — generate a real UUID if publishing to the store
- Tested target: Forerunner 165 (360×360 AMOLED)
